<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Index</title>

	<style>
		body{ background-color: rgb(193,185,136);
			align-items: center ; 
			border: solid;
			margin:150px;
			padding: 40px 400px 40px 400px;}
	</style>
</head>
<body>
      
      <h1>Index page</h1>

      <a href="Controllers/loginController.php">Login Page </a>

</body>
</html>