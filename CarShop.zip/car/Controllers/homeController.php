<?php
session_start();
require_once('../Models/alldb.php');


if(isset($_GET['edit']))
{
    $id=$_GET['edit'];
    $status=edit($id);
    if($status)

     {
        header("location:../Views/Edit.php?Id=$id");
    }
}

if(isset($_GET['booked']))
{
    $carid=$_GET['carid'];
    $res=give($carid);
    $carname=$res->fetch_assoc();
    $brandname=$res->fetch_assoc();
    $price=$res->fetch_assoc();
    $status=mybooked($carid,$carname,$brandname,$price);
    if($status)
    {
        header("location:../Views/customerpage.php");
        $_SESSION['succ']="Inserted";
    }
    else
    {
         header("location:../Views/home.php");
        $_SESSION['succ']="Not Inserted";
    }
}

if(isset($_GET['Delete'])){
    $id=$_GET['Delete'];
    $res=deletebooked($id);
    if($res){
        $_SESSION['del']="Deleted";
        header("location:../Views/admin.php");
    }
}

?>