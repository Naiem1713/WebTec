<?php
require_once('../Models/alldb.php');
session_start();
if(empty($_SESSION['id']))
{
   header("location:../Views/login.php");
}
$res=databooked();

?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Home</title>
</head>
<body>
<h1>Admin page</h1>
Welcome to Dhaka Car Shop,<?php echo $_SESSION['id'];?>

 <table border="1">
    <tr>
       <th>Car Name</th>
       <th>Brand Name</th>
       <th>Car Id</th>
       <th>Price</th>
    </tr>
    <?php while($r=$res->fetch_assoc()) { ?>
    <tr>
       <td><?php echo $r['carname'] ?></td>
       <td><?php echo $r['brandname'] ?></td>
       <td><?php echo $r['carid'] ?></td>
       <td><?php echo $r['price']?></td>


       
      
       <form action="../Controllers/homeController.php" >
       <td><button name="Delete" value="<?php echo $r['carid'] ?>">Delete</button></td>
      
       </form>
    </tr>
 <?php }?>
 
 </table>
 


<form action="../Controllers/loginCheckController.php">
 <button name="logout">Logout</button>
</form>
</body>
</html>