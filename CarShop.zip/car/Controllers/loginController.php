<?php
header("location:../Views/login.php");
?>