<?php 

function con()
{
	$serverName="localhost";
	$userName="root";
	$password="";
	$dbname="web";
	$conn=new mysqli($serverName,$userName,$password,$dbname);
	return $conn;
}

?>