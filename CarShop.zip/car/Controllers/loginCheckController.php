<?php
require_once('../Models/alldb.php');
session_start();
$id=$_POST['id'];
$pass=$_POST['pass'];

if(empty($id || $pass))
{
   $_SESSION['error']="Please fill up the form";
   header("location:../Views/login.php");
}
else
{
	$status=auth($id,$pass);

	if($status=="admin")
	{
		header("location:../Views/admin.php");
		
	}else if($status=="customer"){
		
		header("location:../Views/customerpage.php");
	}
	else
	{
		$_SESSION['error']="Invalid User";
		header("location:../Views/login.php");
	}
}

if(isset($_GET['logout']))
{
	unset($_SESSION['id']);
	header("location:../Views/login.php");

}

?>